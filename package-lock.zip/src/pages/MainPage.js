import React from 'react'
import SuggestedCard from '../components/sugessted_components/SuggestedCard'
import SuggestedContainer from '../components/sugessted_components/SuggestedContainer'

function MainPage() {
  return (
    <section>
        <SuggestedContainer />
    </section>
  )
}

export default MainPage