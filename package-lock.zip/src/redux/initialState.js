export const initialState = {
    register:{
        name: '',
        email: '',
        date_of_birth: '',
        password: ''
    },
    login: {
        username:'',
        password: ''
    },
    user: '',
    suggestedUser: [],
    userData: '',
    blogs: [],
    messagesUsers: [],
    messages: []
}