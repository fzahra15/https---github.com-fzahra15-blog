import React from 'react'

function Logo() {
  return (
    <h2 className="logo">My Blog</h2>

  )
}

export default Logo